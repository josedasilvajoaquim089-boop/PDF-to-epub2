package br.com.pdfparaepub

import android.app.Activity
import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import java.io.ByteArrayOutputStream
import java.io.OutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class MainActivity : Activity() {
    private var pdfUri: Uri? = null
    private var coverUri: Uri? = null
    private lateinit var titleInput: EditText
    private lateinit var authorInput: EditText
    private lateinit var pdfLabel: TextView
    private lateinit var coverLabel: TextView
    private lateinit var status: TextView
    private lateinit var convertButton: Button

    private val pickPdf = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            pdfUri = uri
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            pdfLabel.text = "PDF selecionado: ${fileName(uri)}"
            if (titleInput.text.isBlank()) titleInput.setText(fileName(uri).substringBeforeLast('.'))
        }
    }
    private val pickCover = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            coverUri = uri
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            coverLabel.text = "Capa selecionada: ${fileName(uri)}"
        }
    }
    private val createEpub = registerForActivityResult(ActivityResultContracts.CreateDocument("application/epub+zip")) { uri ->
        if (uri != null) convertTo(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        PDFBoxResourceLoader.init(applicationContext)
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 28, 24, 24); setBackgroundColor(0xFFF7F6FC.toInt()) }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val heading = TextView(this).apply { text = "PDF para EPUB"; textSize = 28f; typeface = Typeface.DEFAULT_BOLD; setTextColor(0xFF30246F.toInt()) }
        content.addView(heading)
        content.addView(TextView(this).apply { text = "Transforme seus PDFs em livros digitais"; textSize = 15f; setTextColor(0xFF55516A.toInt()); setPadding(0, 6, 0, 24) })
        pdfLabel = label("Nenhum PDF selecionado")
        content.addView(actionButton("1. Escolher arquivo PDF") { pickPdf.launch(arrayOf("application/pdf")) })
        content.addView(pdfLabel)
        content.addView(section("Dados do livro"))
        titleInput = edit("Título do livro")
        authorInput = edit("Autor (opcional)")
        content.addView(titleInput); content.addView(authorInput)
        content.addView(section("Capa (opcional)"))
        content.addView(actionButton("2. Escolher imagem para a capa") { pickCover.launch(arrayOf("image/*")) })
        coverLabel = label("Será usada uma capa simples se nenhuma imagem for escolhida")
        content.addView(coverLabel)
        convertButton = actionButton("3. Converter e salvar EPUB") { if (pdfUri == null) toast("Selecione um PDF primeiro") else createEpub.launch((titleInput.text.toString().ifBlank { "Livro" }) + ".epub") }
        convertButton.setBackgroundColor(0xFF5B45C6.toInt()); convertButton.setTextColor(-1)
        content.addView(convertButton)
        status = label("Seus arquivos são processados no próprio aparelho.")
        content.addView(status)
        content.addView(TextView(this).apply { text = "Observação: PDFs digitalizados como imagem (sem texto selecionável) precisam de OCR. Esta versão extrai texto de PDFs que já possuem camada de texto; a diagramação complexa pode mudar na conversão."; textSize = 12f; setTextColor(0xFF686477.toInt()); setPadding(0, 24, 0, 8) })
        scroll.addView(content); root.addView(scroll); setContentView(root)
    }

    private fun section(s: String) = TextView(this).apply { text = s; textSize = 18f; typeface = Typeface.DEFAULT_BOLD; setTextColor(0xFF30246F.toInt()); setPadding(0, 22, 0, 8) }
    private fun label(s: String) = TextView(this).apply { text = s; textSize = 13f; setTextColor(0xFF625E70.toInt()); setPadding(4, 8, 4, 12) }
    private fun edit(hintText: String) = EditText(this).apply { hint = hintText; textSize = 16f; singleLine = true; setPadding(14, 10, 14, 10); background = android.graphics.drawable.GradientDrawable().apply { setColor(-1); cornerRadius = 14f; setStroke(1, 0xFFDAD6E8.toInt()) }; layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 10 } }
    private fun actionButton(textValue: String, action: () -> Unit) = Button(this).apply { text = textValue; isAllCaps = false; textSize = 15f; setOnClickListener { action() }; layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = 8; bottomMargin = 4 } }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    private fun fileName(uri: Uri): String = contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c -> if (c.moveToFirst()) c.getString(0) else "arquivo" } ?: "arquivo"

    private fun convertTo(destination: Uri) {
        val source = pdfUri ?: return
        convertButton.isEnabled = false
        status.text = "Convertendo…"
        Thread {
            try {
                val pdfBytes = contentResolver.openInputStream(source)?.use { it.readBytes() } ?: error("Não foi possível abrir o PDF")
                val document = PDDocument.load(pdfBytes)
                val stripper = PDFTextStripper()
                val pages = mutableListOf<String>()
                for (page in 1..document.numberOfPages) {
                    stripper.startPage = page; stripper.endPage = page
                    pages.add(stripper.getText(document).trim())
                }
                document.close()
                if (pages.all { it.isBlank() }) error("Não foi encontrado texto no PDF. Se ele for digitalizado, será necessário OCR.")
                val title = titleInput.text.toString().ifBlank { "Livro convertido" }
                val author = authorInput.text.toString().ifBlank { "Desconhecido" }
                val cover = coverUri?.let { uri -> contentResolver.openInputStream(uri)?.use { stream -> android.graphics.BitmapFactory.decodeStream(stream)?.let { bitmap -> ByteArrayOutputStream().also { bitmap.compress(android.graphics.Bitmap.CompressFormat.JPEG, 92, it); bitmap.recycle() }.toByteArray() } } }
                contentResolver.openOutputStream(destination)?.use { out -> writeEpub(out, title, author, pages, cover, coverUri?.let { mimeType(it) } ?: "image/jpeg") } ?: error("Não foi possível salvar o EPUB")
                runOnUiThread { status.text = "EPUB criado com sucesso!"; toast("Conversão concluída") }
            } catch (e: Exception) {
                runOnUiThread { status.text = "Erro: ${e.message ?: "falha na conversão"}"; toast("Não foi possível converter o arquivo") }
            } finally { runOnUiThread { convertButton.isEnabled = true } }
        }.start()
    }

    private fun mimeType(uri: Uri): String = contentResolver.getType(uri) ?: "image/jpeg"
    private fun xml(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;").replace("'", "&apos;")

    private fun writeEpub(out: OutputStream, title: String, author: String, pages: List<String>, cover: ByteArray?, coverMime: String) {
        ZipOutputStream(out).use { zip ->
            fun entry(name: String, bytes: ByteArray, method: Int = ZipEntry.DEFLATED) { val e = ZipEntry(name); e.method = method; if (method == ZipEntry.STORED) { e.size = bytes.size.toLong(); e.compressedSize = bytes.size.toLong(); e.crc = java.util.zip.CRC32().apply { update(bytes) }.value }; zip.putNextEntry(e); zip.write(bytes); zip.closeEntry() }
            entry("mimetype", "application/epub+zip".toByteArray(Charsets.US_ASCII), ZipEntry.STORED)
            entry("META-INF/container.xml", """<?xml version="1.0"?><container version="1.0" xmlns="urn:oasis:names:tc:opendocument:xmlns:container"><rootfiles><rootfile full-path="OEBPS/content.opf" media-type="application/oebps-package+xml"/></rootfiles></container>""".toByteArray())
            val imageName = "cover.jpg"
            val imageMime = "image/jpeg"
            val coverMarkup = if (cover != null) "<item id=\"cover-image\" href=\"$imageName\" media-type=\"$imageMime\" properties=\"cover-image\"/>" else ""
            val manifest = pages.indices.joinToString("") { "<item id=\"p${it+1}\" href=\"chapter${it+1}.xhtml\" media-type=\"application/xhtml+xml\"/>" }
            val spine = pages.indices.joinToString("") { "<itemref idref=\"p${it+1}\"/>" }
            val opf = """<?xml version="1.0" encoding="UTF-8"?><package xmlns="http://www.idpf.org/2007/opf" version="3.0" unique-identifier="bookid" xml:lang="pt-BR"><metadata xmlns:dc="http://purl.org/dc/elements/1.1/"><dc:identifier id="bookid">urn:uuid:${java.util.UUID.randomUUID()}</dc:identifier><dc:title>${xml(title)}</dc:title><dc:creator>${xml(author)}</dc:creator><dc:language>pt-BR</dc:language></metadata><manifest><item id="nav" href="nav.xhtml" properties="nav" media-type="application/xhtml+xml"/><item id="css" href="style.css" media-type="text/css"/><item id="cover" href="cover.xhtml" media-type="application/xhtml+xml"/>$coverMarkup$manifest</manifest><spine><itemref idref="cover"/>$spine</spine></package>"""
            entry("OEBPS/content.opf", opf.toByteArray())
            entry("OEBPS/style.css", "body{font-family:serif;line-height:1.55;margin:5%;}h1{text-align:center;} .cover{text-align:center;} img{max-width:100%;max-height:90vh;}".toByteArray())
            val coverXhtml = if (cover != null) "<div class=\"cover\"><img src=\"$imageName\" alt=\"Capa\"/></div>" else "<h1>${xml(title)}</h1><p class=\"cover\">${xml(author)}</p>"
            entry("OEBPS/cover.xhtml", """<?xml version="1.0" encoding="UTF-8"?><html xmlns="http://www.w3.org/1999/xhtml"><head><title>Capa</title><link rel="stylesheet" href="style.css"/></head><body>$coverXhtml</body></html>""".toByteArray())
            if (cover != null) entry("OEBPS/$imageName", cover)
            pages.forEachIndexed { i, page ->
                val paragraphs = page.split(Regex("\\n\\s*\\n")).filter { it.isNotBlank() }.joinToString("") { "<p>${xml(it.trim()).replace("\n", "<br/>")}</p>" }
                val html = """<?xml version="1.0" encoding="UTF-8"?><html xmlns="http://www.w3.org/1999/xhtml" xml:lang="pt-BR"><head><title>${xml(title)} - ${i+1}</title><link rel="stylesheet" href="style.css"/></head><body>$paragraphs</body></html>"""
                entry("OEBPS/chapter${i+1}.xhtml", html.toByteArray(Charsets.UTF_8))
            }
            val nav = """<?xml version="1.0" encoding="UTF-8"?><html xmlns="http://www.w3.org/1999/xhtml" xmlns:epub="http://www.idpf.org/2007/ops"><head><title>Sumário</title></head><body><nav epub:type="toc"><h1>Sumário</h1><ol>${pages.indices.joinToString("") { "<li><a href=\"chapter${it+1}.xhtml\">Página ${it+1}</a></li>" }}</ol></nav></body></html>"""
            entry("OEBPS/nav.xhtml", nav.toByteArray())
        }
    }
}
