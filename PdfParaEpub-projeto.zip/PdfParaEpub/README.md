# PDF para EPUB (Android)

Projeto Android nativo em Kotlin, interface em português e conversão local/offline.

## Recursos
- Seleção de PDF pelo seletor de arquivos do Android.
- Campos para título e autor.
- Seleção opcional de imagem para a capa (a imagem é normalizada para JPEG).
- Exportação EPUB 3 pelo seletor de destino do Android.
- Extração de texto por página com PDFBox-Android.

## Limitações desta versão
- Converte PDFs que possuem camada de texto. PDFs digitalizados como imagem exigem OCR e não são convertidos nesta versão.
- O EPUB é refluível e prioriza o texto; layouts complexos, tabelas, fontes e imagens internas do PDF podem não ser preservados.
- A extração de texto depende da estrutura do PDF e pode exigir revisão em documentos com colunas ou ordem de leitura incomum.

## Como gerar o APK
1. Abra esta pasta no Android Studio (Hedgehog ou mais recente).
2. Aguarde a sincronização do Gradle e a instalação das dependências.
3. Selecione **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. O APK de debug será gerado em `app/build/outputs/apk/debug/app-debug.apk`.

Requisitos: Android Studio com Android SDK 35 e JDK 17. O aplicativo requer Android 8.0 (API 26) ou superior.
